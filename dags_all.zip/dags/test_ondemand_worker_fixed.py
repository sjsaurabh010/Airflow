"""
Fixed Test DAG for On-Demand Workers - Airflow 2.10.2
No deprecation warnings, proper worker setup
"""

from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.empty import EmptyOperator
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator
from airflow.models import Connection
from airflow import settings
import sys
import os

# Add plugins to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'plugins'))

# Try to import the fixed operator
try:
    from operators.remote_worker_operator_fixed import RemoteWorkerOperator
    operator_available = True
except ImportError as e:
    print(f"Warning: Could not import RemoteWorkerOperator: {e}")
    operator_available = False

# Default arguments
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2024, 1, 1),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

# Create DAG
with DAG(
    'test_ondemand_worker_fixed',
    default_args=default_args,
    description='Fixed test DAG for on-demand workers',
    schedule=None,  # Manual trigger - using 'schedule' not 'schedule_interval'
    catchup=False,
    tags=['test', 'on-demand', 'fixed'],
    doc_md="""
    ## Fixed On-Demand Worker Test
    
    This DAG tests the on-demand worker functionality with proper setup:
    1. Creates SSH connection
    2. Starts remote worker with SSH tunnel
    3. Executes task
    4. Monitors execution
    5. Cleans up
    """
) as dag:
    
    # Start task
    start_task = EmptyOperator(
        task_id='start'
    )
    
    # Setup SSH connection (if not exists)
    def setup_ssh_connection(**context):
        """Setup SSH connection in Airflow if not exists"""
        session = settings.Session()
        
        # Check if connection exists
        existing = session.query(Connection).filter(
            Connection.conn_id == 'remote_worker_ssh'
        ).first()
        
        if not existing:
            # Create new connection
            new_conn = Connection(
                conn_id='remote_worker_ssh',
                conn_type='ssh',
                host='10.0.1.10',  # UPDATE WITH YOUR WORKER IP
                login='airflow',
                port=22,
                extra='{"key_file": "/home/airflow/.ssh/id_rsa", "no_host_key_check": true}'
            )
            session.add(new_conn)
            session.commit()
            print("Created SSH connection")
        else:
            print(f"SSH connection exists: {existing.host}")
        
        session.close()
        return "Connection ready"
    
    setup_conn = PythonOperator(
        task_id='setup_ssh_connection',
        python_callable=setup_ssh_connection,
    )
    
    if operator_available:
        # Start remote worker
        start_worker = RemoteWorkerOperator(
            task_id='start_remote_worker',
            ssh_conn_id='remote_worker_ssh',
            worker_name='test-worker-01',
            wait_for_registration=True,
            registration_timeout=60,
        )
        
        # Execute task on remote worker
        remote_task = BashOperator(
            task_id='execute_on_worker',
            bash_command="""
            echo "Task executing on worker"
            echo "Date: $(date)"
            echo "Hostname: $(hostname)"
            """,
            queue='test-worker-01',  # Route to specific worker
        )
        
        # Stop worker
        stop_worker = BashOperator(
            task_id='stop_remote_worker',
            bash_command="""
            echo "Stopping remote worker..."
            # This would normally SSH and stop the worker
            # For now, just log
            echo "Worker stop signal sent"
            """,
        )
    else:
        # Fallback if operator not available
        start_worker = BashOperator(
            task_id='start_remote_worker',
            bash_command='echo "RemoteWorkerOperator not available - using fallback"',
        )
        
        remote_task = BashOperator(
            task_id='execute_on_worker',
            bash_command='echo "Running locally as fallback"',
        )
        
        stop_worker = BashOperator(
            task_id='stop_remote_worker',
            bash_command='echo "No worker to stop"',
        )
    
    # Monitor results
    def check_results(**context):
        """Check task execution results"""
        ti = context['task_instance']
        
        # Get task states
        dag_run = context['dag_run']
        task_instances = dag_run.get_task_instances()
        
        print("=" * 60)
        print("EXECUTION SUMMARY")
        print("=" * 60)
        
        for ti in task_instances:
            print(f"Task: {ti.task_id} - State: {ti.state}")
        
        print("=" * 60)
        return "Check complete"
    
    check_task = PythonOperator(
        task_id='check_results',
        python_callable=check_results,
    )
    
    # End task
    end_task = EmptyOperator(
        task_id='end'
    )
    
    # Define dependencies
    start_task >> setup_conn >> start_worker >> remote_task >> stop_worker >> check_task >> end_task


# Alternative Simple Test DAG
with DAG(
    'simple_worker_test',
    default_args=default_args,
    description='Simple test without custom operators',
    schedule=None,
    catchup=False,
    tags=['simple', 'test'],
) as simple_dag:
    
    start = EmptyOperator(task_id='start')
    
    # Test SSH connection
    test_ssh = BashOperator(
        task_id='test_ssh_connection',
        bash_command="""
        # Test if we can SSH to worker
        ssh -o StrictHostKeyChecking=no airflow@10.0.1.10 "echo 'SSH OK'" || echo "SSH Failed"
        """,
    )
    
    # Start worker manually
    start_worker_manual = BashOperator(
        task_id='start_worker_manually',
        bash_command="""
        ssh -o StrictHostKeyChecking=no airflow@10.0.1.10 << 'EOF'
# Start worker
export AIRFLOW_HOME=/home/airflow/airflow
cd $AIRFLOW_HOME

# Check if worker is already running
if pgrep -f "celery.*worker" > /dev/null; then
    echo "Worker already running"
else
    echo "Starting new worker..."
    # Start in background
    nohup celery -A airflow.providers.celery.executors.celery_executor.app worker \
        --hostname=manual-worker \
        --queues=default \
        --loglevel=info \
        > /tmp/manual_worker.log 2>&1 &
    
    sleep 5
    echo "Worker started"
fi
EOF
        """,
    )
    
    # Execute simple task
    execute = BashOperator(
        task_id='execute_task',
        bash_command='echo "Executing task at $(date)"',
    )
    
    end = EmptyOperator(task_id='end')
    
    start >> test_ssh >> start_worker_manual >> execute >> end
