"""
Test DAG for Redis and PostgreSQL Connectivity
Shows detailed connection testing with logging
"""

from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.bash import BashOperator
from airflow.operators.empty import EmptyOperator
from airflow.hooks.base import BaseHook
from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.providers.redis.hooks.redis import RedisHook
import logging
import socket
import os
import json
import traceback

# Setup logger
logger = logging.getLogger(__name__)

# Default arguments
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2024, 1, 1),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=1),
}

def test_postgresql_connection(**context):
    """Test PostgreSQL connectivity and perform basic operations"""
    logger.info("="*60)
    logger.info("STARTING POSTGRESQL CONNECTION TEST")
    logger.info("="*60)
    
    results = {
        'timestamp': datetime.now().isoformat(),
        'hostname': socket.gethostname(),
        'worker': context.get('task_instance').hostname if context.get('task_instance') else 'unknown',
    }
    
    logger.info(f"📍 Current Location: {socket.gethostname()}")
    logger.info(f"📍 Current Time: {datetime.now()}")
    logger.info(f"📍 Task Instance Worker: {results['worker']}")
    
    try:
        logger.info("\n🔄 STEP 1: Now I am going to import required libraries...")
        from sqlalchemy import create_engine
        import psycopg2
        logger.info("✅ Libraries imported successfully")
        
        logger.info("\n🔄 STEP 2: Now I am going to get database connection details from Airflow config...")
        from airflow.configuration import conf
        db_url = conf.get('database', 'sql_alchemy_conn')
        logger.info(f"✅ Got database URL: {db_url.split('@')[0]}@...")
        
        logger.info("\n🔄 STEP 3: Now I am going to parse the connection string to extract host and port...")
        if 'postgresql' in db_url:
            # Extract host and port
            import re
            match = re.search(r'@([^:/]+):?(\d+)?/', db_url)
            if match:
                host = match.group(1)
                port = match.group(2) or '5432'
                logger.info(f"✅ Extracted connection details - Host: {host}, Port: {port}")
                results['postgres_host'] = host
                results['postgres_port'] = port
        
        logger.info("\n🔄 STEP 4: Now I am going to setup PostgreSQL connection using Airflow's PostgresHook...")
        try:
            logger.info("🔄 STEP 4a: Now I am going to check if postgres_default connection exists...")
            from airflow.models import Connection
            from airflow import settings
            
            session = settings.Session()
            
            existing = session.query(Connection).filter(
                Connection.conn_id == 'postgres_default'
            ).first()
            
            if not existing:
                logger.info("⚠️ Connection does not exist. Now I am going to create it...")
                if 'postgresql' in db_url:
                    parts = db_url.replace('postgresql+psycopg2://', '').split('@')
                    user_pass = parts[0].split(':')
                    host_db = parts[1].split('/')
                    host_port = host_db[0].split(':')
                    
                    new_conn = Connection(
                        conn_id='postgres_default',
                        conn_type='postgres',
                        host=host_port[0],
                        schema=host_db[1] if len(host_db) > 1 else 'airflow',
                        login=user_pass[0],
                        password=user_pass[1] if len(user_pass) > 1 else None,
                        port=int(host_port[1]) if len(host_port) > 1 else 5432
                    )
                    session.add(new_conn)
                    session.commit()
                    logger.info("✅ Created postgres_default connection successfully")
            else:
                logger.info("✅ Connection already exists")
            
            session.close()
            
            logger.info("\n🔄 STEP 5: Now I am going to connect to PostgreSQL using the hook...")
            pg_hook = PostgresHook(postgres_conn_id='postgres_default')
            conn = pg_hook.get_conn()
            cursor = conn.cursor()
            logger.info("✅ Successfully connected to PostgreSQL!")
            
            logger.info("\n🔄 STEP 6: Now I am going to run test queries...")
            
            logger.info("   📝 Query 1: Getting PostgreSQL version...")
            cursor.execute("SELECT version();")
            version = cursor.fetchone()[0]
            logger.info(f"   ✅ PostgreSQL Version: {version[:50]}...")
            results['postgres_version'] = version[:100]
            
            logger.info("   📝 Query 2: Getting current database name...")
            cursor.execute("SELECT current_database();")
            db_name = cursor.fetchone()[0]
            logger.info(f"   ✅ Current Database: {db_name}")
            results['database_name'] = db_name
            
            logger.info("   📝 Query 3: Counting total DAG runs...")
            cursor.execute("SELECT COUNT(*) FROM dag_run;")
            dag_run_count = cursor.fetchone()[0]
            logger.info(f"   ✅ Total DAG runs in database: {dag_run_count}")
            results['dag_run_count'] = dag_run_count
            
            logger.info("   📝 Query 4: Getting list of tables...")
            cursor.execute("""
                SELECT tablename FROM pg_tables 
                WHERE schemaname = 'public' 
                LIMIT 10;
            """)
            tables = [row[0] for row in cursor.fetchall()]
            logger.info(f"   ✅ Sample tables: {', '.join(tables[:5])}")
            results['sample_tables'] = tables[:5]
            
            cursor.close()
            conn.close()
            
            results['postgres_status'] = 'SUCCESS'
            logger.info("\n✅ PostgreSQL connection successful!")
            
        except Exception as e:
            logger.error(f"PostgresHook error: {str(e)}")
            results['postgres_hook_error'] = str(e)
            
            # Try direct psycopg2 connection
            logger.info("\n--- Trying direct psycopg2 connection ---")
            import psycopg2
            
            # For workers using SSH tunnel, try localhost
            for host in ['localhost', '127.0.0.1', 'postgres', 'airflow-postgres']:
                try:
                    conn = psycopg2.connect(
                        host=host,
                        port=5432,
                        database='airflow',
                        user='airflow',
                        password='airflow'
                    )
                    cursor = conn.cursor()
                    cursor.execute("SELECT 1;")
                    cursor.close()
                    conn.close()
                    logger.info(f"✅ Direct connection successful to {host}")
                    results['postgres_status'] = 'SUCCESS'
                    results['working_host'] = host
                    break
                except Exception as conn_err:
                    logger.warning(f"Failed to connect to {host}: {str(conn_err)}")
            
    except Exception as e:
        logger.error(f"❌ PostgreSQL connection failed: {str(e)}")
        logger.error(traceback.format_exc())
        results['postgres_status'] = 'FAILED'
        results['postgres_error'] = str(e)
        raise
    
    # Push results to XCom for other tasks to use
    context['task_instance'].xcom_push(key='postgres_test_results', value=results)
    
    return results

def test_redis_connection(**context):
    """Test Redis connectivity and perform basic operations"""
    logger.info("="*60)
    logger.info("STARTING REDIS CONNECTION TEST")
    logger.info("="*60)
    
    results = {
        'timestamp': datetime.now().isoformat(),
        'hostname': socket.gethostname(),
        'worker': context.get('task_instance').hostname if context.get('task_instance') else 'unknown',
    }
    
    logger.info(f"📍 Current Location: {socket.gethostname()}")
    logger.info(f"📍 Current Time: {datetime.now()}")
    logger.info(f"📍 Task Instance Worker: {results['worker']}")
    
    try:
        logger.info("\n🔄 STEP 1: Now I am going to get Redis connection details from Airflow config...")
        from airflow.configuration import conf
        broker_url = conf.get('celery', 'broker_url')
        logger.info(f"✅ Got broker URL: {broker_url.split('@')[0] if '@' in broker_url else broker_url.split('//')[0] + '//...'}")
        
        logger.info("\n🔄 STEP 2: Now I am going to parse Redis connection URL to extract host, port, and database...")
        if 'redis' in broker_url:
            import re
            match = re.search(r'redis://(?::([^@]+)@)?([^:/]+):?(\d+)?/(\d+)?', broker_url)
            if match:
                password = match.group(1)
                host = match.group(2)
                port = match.group(3) or '6379'
                db = match.group(4) or '0'
                logger.info(f"✅ Extracted Redis details - Host: {host}, Port: {port}, Database: {db}")
                results['redis_host'] = host
                results['redis_port'] = port
                results['redis_db'] = db
        
        logger.info("\n🔄 STEP 3: Now I am going to setup Redis connection using RedisHook...")
        try:
            logger.info("🔄 STEP 3a: Now I am going to check if redis_default connection exists...")
            from airflow.models import Connection
            from airflow import settings
            
            session = settings.Session()
            
            existing = session.query(Connection).filter(
                Connection.conn_id == 'redis_default'
            ).first()
            
            if not existing:
                logger.info("⚠️ Connection does not exist. Now I am going to create it...")
                if 'redis' in broker_url:
                    import re
                    match = re.search(r'redis://(?::([^@]+)@)?([^:/]+):?(\d+)?/(\d+)?', broker_url)
                    if match:
                        new_conn = Connection(
                            conn_id='redis_default',
                            conn_type='redis',
                            host=match.group(2),
                            password=match.group(1),
                            port=int(match.group(3) or 6379),
                            extra=json.dumps({'db': int(match.group(4) or 0)})
                        )
                        session.add(new_conn)
                        session.commit()
                        logger.info("✅ Created redis_default connection successfully")
            else:
                logger.info("✅ Connection already exists")
            
            session.close()
            
            logger.info("\n🔄 STEP 4: Now I am going to connect to Redis using the hook...")
            redis_hook = RedisHook(redis_conn_id='redis_default')
            redis_client = redis_hook.get_conn()
            logger.info("✅ Successfully connected to Redis!")
            
            logger.info("\n🔄 STEP 5: Now I am going to run Redis test operations...")
            
            logger.info("   📝 Operation 1: Testing Redis PING command...")
            ping_result = redis_client.ping()
            logger.info(f"   ✅ Redis PING response: {ping_result}")
            results['redis_ping'] = ping_result
            
            logger.info("   📝 Operation 2: Testing SET and GET operations...")
            test_key = f"airflow_test_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            test_value = f"Test from {socket.gethostname()} at {datetime.now()}"
            logger.info(f"      Setting key: {test_key}")
            redis_client.set(test_key, test_value, ex=60)  # Expire in 60 seconds
            logger.info(f"      Getting key back...")
            retrieved_value = redis_client.get(test_key)
            logger.info(f"   ✅ Redis SET/GET successful: Value={retrieved_value.decode() if retrieved_value else None}")
            results['redis_test_key'] = test_key
            
            logger.info("   📝 Operation 3: Checking for Celery queues...")
            celery_queues = redis_client.keys('celery*')
            logger.info(f"   ✅ Found {len(celery_queues)} Celery queue(s)")
            if celery_queues:
                logger.info(f"      Queue names: {[q.decode() if isinstance(q, bytes) else q for q in celery_queues[:5]]}")
            results['celery_queue_count'] = len(celery_queues)
            
            logger.info("   📝 Operation 4: Getting Redis server information...")
            info = redis_client.info()
            logger.info(f"   ✅ Redis version: {info.get('redis_version', 'unknown')}")
            logger.info(f"   ✅ Connected clients: {info.get('connected_clients', 'unknown')}")
            logger.info(f"   ✅ Used memory: {info.get('used_memory_human', 'unknown')}")
            results['redis_version'] = info.get('redis_version', 'unknown')
            results['redis_clients'] = info.get('connected_clients', 'unknown')
            results['redis_memory'] = info.get('used_memory_human', 'unknown')
            
            results['redis_status'] = 'SUCCESS'
            logger.info("\n✅ Redis connection successful!")
            
        except Exception as e:
            logger.error(f"RedisHook error: {str(e)}")
            results['redis_hook_error'] = str(e)
            
            # Try direct redis connection
            logger.info("\n--- Trying direct Redis connection ---")
            import redis
            
            # For workers using SSH tunnel, try localhost
            for host in ['localhost', '127.0.0.1', 'redis', 'airflow-redis']:
                for port in [6379, 6380]:
                    try:
                        r = redis.Redis(host=host, port=port, db=0, socket_timeout=5)
                        r.ping()
                        logger.info(f"✅ Direct Redis connection successful to {host}:{port}")
                        results['redis_status'] = 'SUCCESS'
                        results['working_redis'] = f"{host}:{port}"
                        break
                    except Exception as conn_err:
                        logger.warning(f"Failed to connect to {host}:{port}: {str(conn_err)}")
                if results.get('redis_status') == 'SUCCESS':
                    break
                    
    except Exception as e:
        logger.error(f"❌ Redis connection failed: {str(e)}")
        logger.error(traceback.format_exc())
        results['redis_status'] = 'FAILED'
        results['redis_error'] = str(e)
        raise
    
    # Push results to XCom
    context['task_instance'].xcom_push(key='redis_test_results', value=results)
    
    return results

def show_worker_info(**context):
    """Display information about the current worker"""
    logger.info("="*60)
    logger.info("WORKER INFORMATION")
    logger.info("="*60)
    
    import platform
    import subprocess
    
    info = {
        'timestamp': datetime.now().isoformat(),
        'hostname': socket.gethostname(),
        'platform': platform.platform(),
        'python_version': platform.python_version(),
        'airflow_home': os.environ.get('AIRFLOW_HOME', 'not set'),
        'working_directory': os.getcwd(),
    }
    
    # Get task instance info
    ti = context.get('task_instance')
    if ti:
        info['task_id'] = ti.task_id
        info['dag_id'] = ti.dag_id
        info['execution_date'] = str(ti.execution_date)
        info['worker_hostname'] = ti.hostname
        info['queue'] = ti.queue
    
    # Check if running in container
    if os.path.exists('/.singularity.d'):
        info['container'] = 'Singularity'
        logger.info("🐳 Running inside Singularity container")
    elif os.path.exists('/.dockerenv'):
        info['container'] = 'Docker'
        logger.info("🐳 Running inside Docker container")
    else:
        info['container'] = 'None'
        logger.info("💻 Running on bare metal/VM")
    
    # Check network connectivity
    logger.info("\n--- Network Connectivity ---")
    for host, port in [('localhost', 5432), ('localhost', 6379), ('127.0.0.1', 5432), ('127.0.0.1', 6379)]:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(2)
            result = sock.connect_ex((host, port))
            sock.close()
            status = "✅ Open" if result == 0 else "❌ Closed"
            logger.info(f"{host}:{port} - {status}")
            info[f'port_{host}_{port}'] = result == 0
        except Exception as e:
            logger.error(f"Error checking {host}:{port}: {e}")
    
    # Check SSH tunnels
    try:
        result = subprocess.run(['ps', 'aux'], capture_output=True, text=True, timeout=5)
        ssh_tunnels = [line for line in result.stdout.split('\n') if 'ssh' in line.lower() and '-L' in line]
        info['ssh_tunnels_count'] = len(ssh_tunnels)
        logger.info(f"\n✅ Found {len(ssh_tunnels)} SSH tunnel(s)")
        for tunnel in ssh_tunnels[:3]:  # Show first 3
            logger.info(f"  {tunnel[:100]}...")
    except Exception as e:
        logger.warning(f"Could not check SSH tunnels: {e}")
    
    # Log all info
    logger.info("\n--- Complete Worker Info ---")
    for key, value in info.items():
        logger.info(f"{key}: {value}")
    
    return info

def generate_summary(**context):
    """Generate a summary of all connection tests"""
    logger.info("="*60)
    logger.info("CONNECTION TEST SUMMARY")
    logger.info("="*60)
    
    # Get results from previous tasks
    ti = context['task_instance']
    postgres_results = ti.xcom_pull(task_ids='test_postgresql', key='postgres_test_results')
    redis_results = ti.xcom_pull(task_ids='test_redis', key='redis_test_results')
    
    summary = {
        'timestamp': datetime.now().isoformat(),
        'dag_run_id': context['dag_run'].run_id,
        'execution_date': str(context['execution_date']),
    }
    
    # PostgreSQL Summary
    if postgres_results:
        pg_status = postgres_results.get('postgres_status', 'UNKNOWN')
        logger.info(f"\n📊 PostgreSQL Status: {pg_status}")
        if pg_status == 'SUCCESS':
            logger.info(f"   ✅ Database: {postgres_results.get('database_name', 'N/A')}")
            logger.info(f"   ✅ DAG Runs: {postgres_results.get('dag_run_count', 'N/A')}")
            logger.info(f"   ✅ Host: {postgres_results.get('working_host', postgres_results.get('postgres_host', 'N/A'))}")
        else:
            logger.error(f"   ❌ Error: {postgres_results.get('postgres_error', 'Unknown error')}")
        summary['postgresql'] = pg_status
    
    # Redis Summary
    if redis_results:
        redis_status = redis_results.get('redis_status', 'UNKNOWN')
        logger.info(f"\n📊 Redis Status: {redis_status}")
        if redis_status == 'SUCCESS':
            logger.info(f"   ✅ Version: {redis_results.get('redis_version', 'N/A')}")
            logger.info(f"   ✅ Clients: {redis_results.get('redis_clients', 'N/A')}")
            logger.info(f"   ✅ Memory: {redis_results.get('redis_memory', 'N/A')}")
            logger.info(f"   ✅ Host: {redis_results.get('working_redis', redis_results.get('redis_host', 'N/A'))}")
        else:
            logger.error(f"   ❌ Error: {redis_results.get('redis_error', 'Unknown error')}")
        summary['redis'] = redis_status
    
    # Overall Status
    all_success = (
        postgres_results and postgres_results.get('postgres_status') == 'SUCCESS' and
        redis_results and redis_results.get('redis_status') == 'SUCCESS'
    )
    
    logger.info("\n" + "="*60)
    if all_success:
        logger.info("🎉 ALL CONNECTIONS SUCCESSFUL! 🎉")
        summary['overall'] = 'SUCCESS'
    else:
        logger.error("⚠️ SOME CONNECTIONS FAILED - CHECK LOGS ⚠️")
        summary['overall'] = 'FAILED'
    logger.info("="*60)
    
    return summary

# Create the DAG
with DAG(
    'test_connections',
    default_args=default_args,
    description='Test Redis and PostgreSQL connectivity with detailed logging',
    schedule=None,  # Manual trigger only
    catchup=False,
    tags=['test', 'connections', 'debug'],
    doc_md="""
    # Connection Test DAG
    
    This DAG tests connectivity to Redis and PostgreSQL from workers.
    
    ## Tasks:
    1. **show_environment** - Display environment variables
    2. **test_postgresql** - Test PostgreSQL connection and queries
    3. **test_redis** - Test Redis connection and operations
    4. **show_worker_info** - Display worker information
    5. **generate_summary** - Summarize all test results
    
    ## How to View Logs:
    
    ### Option 1: Airflow Web UI
    1. Go to http://your-master-ip:8080
    2. Click on this DAG (test_connections)
    3. Click on a DAG run (green/red circle)
    4. Click on any task box
    5. Click "Log" to see detailed logs
    
    ### Option 2: Command Line
    ```bash
    # View specific task log
    airflow tasks logs test_connections test_postgresql 2024-01-01
    
    # View all logs for a DAG run
    cat ~/airflow/logs/dag_id=test_connections/run_id=*/task_id=*/*.log
    ```
    
    ### Option 3: Real-time logs
    ```bash
    # Follow scheduler logs
    tail -f ~/airflow/logs/scheduler/latest/*.log
    
    # Follow worker logs
    tail -f /tmp/worker_*.log
    ```
    
    ## Troubleshooting:
    - If PostgreSQL fails: Check SSH tunnel on port 5432
    - If Redis fails: Check SSH tunnel on port 6379
    - If both fail: Worker may not have tunnel setup
    """
) as dag:
    
    # Show environment variables
    show_env = BashOperator(
        task_id='show_environment',
        bash_command="""
        echo "========================================="
        echo "ENVIRONMENT VARIABLES"
        echo "========================================="
        echo "AIRFLOW_HOME: $AIRFLOW_HOME"
        echo "HOSTNAME: $(hostname)"
        echo "DATE: $(date)"
        echo "PWD: $(pwd)"
        echo ""
        echo "Network Interfaces:"
        ip addr show 2>/dev/null || ifconfig 2>/dev/null || echo "No network info available"
        echo ""
        echo "Checking ports:"
        netstat -tuln 2>/dev/null | grep -E ':(5432|6379)' || ss -tuln | grep -E ':(5432|6379)' || echo "No port info"
        echo "========================================="
        """
    )
    
    # Test PostgreSQL
    test_pg = PythonOperator(
        task_id='test_postgresql',
        python_callable=test_postgresql_connection,
        provide_context=True,
    )
    
    # Test Redis
    test_redis_task = PythonOperator(
        task_id='test_redis',
        python_callable=test_redis_connection,
        provide_context=True,
    )
    
    # Show worker info
    worker_info = PythonOperator(
        task_id='show_worker_info',
        python_callable=show_worker_info,
        provide_context=True,
    )
    
    # Generate summary
    summary = PythonOperator(
        task_id='generate_summary',
        python_callable=generate_summary,
        provide_context=True,
        trigger_rule='none_failed_min_one_success',  # Run even if some tasks fail
    )
    
    # Define task dependencies
    show_env >> [test_pg, test_redis_task, worker_info] >> summary


# Create a simpler version for quick testing
with DAG(
    'quick_connection_test',
    default_args=default_args,
    description='Quick connection test using bash commands',
    schedule=None,
    catchup=False,
    tags=['test', 'quick'],
) as quick_dag:
    
    quick_test = BashOperator(
        task_id='quick_test_all',
        bash_command="""
        echo "===== QUICK CONNECTION TEST ====="
        echo "Timestamp: $(date)"
        echo "Hostname: $(hostname)"
        echo ""
        
        echo "Testing PostgreSQL..."
        PGPASSWORD=airflow psql -h localhost -U airflow -d airflow -c "SELECT version();" 2>&1 || echo "PostgreSQL: FAILED"
        echo ""
        
        echo "Testing Redis..."
        redis-cli -h localhost ping 2>&1 || echo "Redis: FAILED"
        echo ""
        
        echo "Checking SSH tunnels..."
        ps aux | grep -E "ssh.*-L" | grep -v grep || echo "No SSH tunnels found"
        echo ""
        
        echo "===== END TEST ====="
        """
    )
